import random
import datetime
from colorama import Fore, Back, Style
import sys
import requests
url = 'https://pastebin.com/raw/YLwvGjts'
r = requests.get(url)
CURRENT_VER = r.text
Ver = "0.1.4.2"
VERCOLOR = Fore.GREEN
## Settings Base
PasswordProtected = False ## Enables Password Protection, Cant be edited outside program. 
Password = "Password" ## Change Me! - Dial
Logos = True ## Toggles ASCII Art - Dial

if Logos == True:
   f23= open ('logo.text','r')
   f233= open ('danger.text','r')
else:
  f23= open ('Nologo.text','r')
  f233= open ('Nologo.text','r')

if Ver != CURRENT_VER:
  VERCOLOR = Fore.RED
  print(Fore.RED + "{!} You're using an outdated version of FrontManager. You're running " + Ver + ". The current verison is " + CURRENT_VER + ".")
  print(Style.RESET_ALL)
  Ack = input("Would you like to know how to migrate your files? Type *YES* to begin, Type anything else to ignore. \n")

  if Ack == "YES":
    print("First. Head to: \n https://github.com/CyberAdmin1/FrontManager")
    input("Type anything to continue.")
    print("Second, download the latest version. Which is " + CURRENT_VER)
    input("Type anything to continue.")
    print("Third, after this direction. Enter your password if FrontManager is configured with a password. \n Then, when prompted. type *SEE*, and press 1.")
    input("Type anything to continue.")
    print("Lastly, find the file Fronter.text, and open it. When opened, paste the old logs into it.")
    input("Type anything to return to REGULAR OPERATION.")
  else:
    print("Exiting.")
else:


  print("Program loaded.")
print("Program written by Clyde#2021 on Discord.")
print(Fore.RED + '[!] License is GNU AGPLv3. Read License document.')
print("Software Written by PlurallyDial")
print(Style.RESET_ALL)

print(VERCOLOR)
print(''.join([line for line in f23]))
print("----------------------------------------------")
x = datetime.datetime.now()
print(Style.RESET_ALL)
FINAL_DATE = str(x)
f3 = open("Fail.text", "a")


if PasswordProtected == True:
  print("This Program is Password Protected. Enter Password. You have 1 try.")
  Input1 = input("Enter Password: \n")
  if Input1 != Password:
    Access = False
    Access_Str = str(Access)
    print("Incorrect")
    f3.write("{")
    f3.write(FINAL_DATE)
    f3.write("\n")
    f3.write("Failed Attempt. Password Attempt was" + Input1 + " Password is " + Password + " Access Variable remained as" + Access_Str)
    f3.write("\n}")
    print(Fore.RED)
    print(''.join([line for line in f233]))
    print("-------------------------------------------------------------------")
    print("You've entered the wrong password on this application of FrontManager. If this is really you who owns this, try again.")
    sys.exit("Incorrect Password: FAULT_USER")
  else:
    Access = True
else: 
  Access = True
if Access == True:

  f2 = open("Current.text", "rt")
  Action = input("Set Front, See Front, or Randomize Protector? SET, SEE, RAND \n")
  
  
  if Action == "RAND":
    print("1-3 is default. Alter code if needed.")
    NAME1 = input("First Alter \n")
    NAME2 = input("Second Alter \n")
    NAME3 = input("Third Alter \n ")
    print("------------------------")
    print(NAME1 + "'s code is 1")
    print(NAME2 + "'s code is 2")
    print(NAME3 + "'s code is 3")
    print("------------------------")
    PICK1 = random.randint(1, 3)
    PICK2 = random.randint(1, 3)
    PICK3 = random.randint(1, 3)
    FINAL = PICK1, PICK2, PICK3
    FINAL_STR = str(FINAL)
    FINAL_DATE = str(x)
    print(PICK1, PICK2, PICK3)
    f = open("RAND.text", "a")
    f.write(FINAL_DATE)
    f.write(FINAL_STR)
    f.write("\n")
    f.close()
  else:
    if Action == "SET":
      Awake = input("Who is currently fronting? List As much as required. \n")
      Sleeping = input("Who is currently sleeping? List as much as required. Feel free to put None \n")
      CurrentFront = Awake, " <-Awake | Sleeping -> ",   Sleeping
      CurrentFront_STRING = str(CurrentFront)
      f = open("Fronter.text", "a")
      f2 = open("Current.text", "w")
      f2.write(CurrentFront_STRING)
      f.write("{")
      f.write(FINAL_DATE)
      f.write("\n")
      f.write(CurrentFront_STRING)
      f.write("}")
      f.write("\n")
      f.close()
      f2.close()
    else:
  
     if Action == "SEE":
      Typ = input("1. Read Full or 2. Current Front? 1/2 \n")
    
      if Typ == "1":
        f = open("Fronter.text", "r")
        print(f.read())
      else:

       if Typ == "2":
        f = open("Current.text", "r")
        Cur = f2.read()
        Output = str(Cur)
        print(Output)
        
     

   
    